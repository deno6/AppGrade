﻿namespace projekt_appGrade
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.korimeKorisnika = new System.Windows.Forms.Label();
            this.lozinkaKorsnika = new System.Windows.Forms.Label();
            this.korimeUnos = new System.Windows.Forms.TextBox();
            this.lozinkaUnos = new System.Windows.Forms.TextBox();
            this.zapamtiKorisnika = new System.Windows.Forms.CheckBox();
            this.prijavaKorisnika = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // korimeKorisnika
            // 
            this.korimeKorisnika.AutoSize = true;
            this.korimeKorisnika.Location = new System.Drawing.Point(184, 145);
            this.korimeKorisnika.Name = "korimeKorisnika";
            this.korimeKorisnika.Size = new System.Drawing.Size(81, 13);
            this.korimeKorisnika.TabIndex = 0;
            this.korimeKorisnika.Text = "Korisničko ime: ";
            // 
            // lozinkaKorsnika
            // 
            this.lozinkaKorsnika.AutoSize = true;
            this.lozinkaKorsnika.Location = new System.Drawing.Point(184, 188);
            this.lozinkaKorsnika.Name = "lozinkaKorsnika";
            this.lozinkaKorsnika.Size = new System.Drawing.Size(50, 13);
            this.lozinkaKorsnika.TabIndex = 1;
            this.lozinkaKorsnika.Text = "Lozinka: ";
            // 
            // korimeUnos
            // 
            this.korimeUnos.Location = new System.Drawing.Point(289, 138);
            this.korimeUnos.Name = "korimeUnos";
            this.korimeUnos.Size = new System.Drawing.Size(100, 20);
            this.korimeUnos.TabIndex = 2;
            // 
            // lozinkaUnos
            // 
            this.lozinkaUnos.Location = new System.Drawing.Point(289, 181);
            this.lozinkaUnos.Name = "lozinkaUnos";
            this.lozinkaUnos.Size = new System.Drawing.Size(100, 20);
            this.lozinkaUnos.TabIndex = 3;
            // 
            // zapamtiKorisnika
            // 
            this.zapamtiKorisnika.AutoSize = true;
            this.zapamtiKorisnika.Location = new System.Drawing.Point(308, 221);
            this.zapamtiKorisnika.Name = "zapamtiKorisnika";
            this.zapamtiKorisnika.Size = new System.Drawing.Size(81, 17);
            this.zapamtiKorisnika.TabIndex = 4;
            this.zapamtiKorisnika.Text = "Zapamti me";
            this.zapamtiKorisnika.UseVisualStyleBackColor = true;
            // 
            // prijavaKorisnika
            // 
            this.prijavaKorisnika.Location = new System.Drawing.Point(314, 296);
            this.prijavaKorisnika.Name = "prijavaKorisnika";
            this.prijavaKorisnika.Size = new System.Drawing.Size(75, 23);
            this.prijavaKorisnika.TabIndex = 5;
            this.prijavaKorisnika.Text = "Prijavi se";
            this.prijavaKorisnika.UseVisualStyleBackColor = true;
            this.prijavaKorisnika.Click += new System.EventHandler(this.prijavaKorisnika_Click);
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 435);
            this.Controls.Add(this.prijavaKorisnika);
            this.Controls.Add(this.zapamtiKorisnika);
            this.Controls.Add(this.lozinkaUnos);
            this.Controls.Add(this.korimeUnos);
            this.Controls.Add(this.lozinkaKorsnika);
            this.Controls.Add(this.korimeKorisnika);
            this.Name = "frmLogin";
            this.Text = "Sportski centar \"Z Mača\"";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label korimeKorisnika;
        private System.Windows.Forms.Label lozinkaKorsnika;
        private System.Windows.Forms.TextBox korimeUnos;
        private System.Windows.Forms.TextBox lozinkaUnos;
        private System.Windows.Forms.CheckBox zapamtiKorisnika;
        private System.Windows.Forms.Button prijavaKorisnika;
    }
}
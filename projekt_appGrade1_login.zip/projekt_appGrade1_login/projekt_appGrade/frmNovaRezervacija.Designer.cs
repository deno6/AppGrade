﻿namespace projekt_appGrade
{
    partial class NovaRezervacija
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.imeClana = new System.Windows.Forms.Label();
            this.imeUpis = new System.Windows.Forms.TextBox();
            this.prezimeClana = new System.Windows.Forms.Label();
            this.vrstaSporta = new System.Windows.Forms.Label();
            this.datumRezervacije = new System.Windows.Forms.Label();
            this.vrijemeRezervacije = new System.Windows.Forms.Label();
            this.adresaClana = new System.Windows.Forms.Label();
            this.kontaktBroj = new System.Windows.Forms.Label();
            this.prezimeUpis = new System.Windows.Forms.TextBox();
            this.adresaUpis = new System.Windows.Forms.TextBox();
            this.sportIzbor = new System.Windows.Forms.ComboBox();
            this.datumIzbor = new System.Windows.Forms.DateTimePicker();
            this.vrijemeUpis = new System.Windows.Forms.TextBox();
            this.kontaktUpis = new System.Windows.Forms.TextBox();
            this.pohraniClana = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // imeClana
            // 
            this.imeClana.AutoSize = true;
            this.imeClana.Location = new System.Drawing.Point(52, 34);
            this.imeClana.Name = "imeClana";
            this.imeClana.Size = new System.Drawing.Size(24, 13);
            this.imeClana.TabIndex = 0;
            this.imeClana.Text = "Ime";
            this.imeClana.Click += new System.EventHandler(this.label1_Click);
            // 
            // imeUpis
            // 
            this.imeUpis.Location = new System.Drawing.Point(118, 31);
            this.imeUpis.Name = "imeUpis";
            this.imeUpis.Size = new System.Drawing.Size(189, 20);
            this.imeUpis.TabIndex = 1;
            // 
            // prezimeClana
            // 
            this.prezimeClana.AutoSize = true;
            this.prezimeClana.Location = new System.Drawing.Point(52, 76);
            this.prezimeClana.Name = "prezimeClana";
            this.prezimeClana.Size = new System.Drawing.Size(44, 13);
            this.prezimeClana.TabIndex = 2;
            this.prezimeClana.Text = "Prezime";
            // 
            // vrstaSporta
            // 
            this.vrstaSporta.AutoSize = true;
            this.vrstaSporta.Location = new System.Drawing.Point(52, 157);
            this.vrstaSporta.Name = "vrstaSporta";
            this.vrstaSporta.Size = new System.Drawing.Size(32, 13);
            this.vrstaSporta.TabIndex = 3;
            this.vrstaSporta.Text = "Sport";
            // 
            // datumRezervacije
            // 
            this.datumRezervacije.AutoSize = true;
            this.datumRezervacije.Location = new System.Drawing.Point(52, 196);
            this.datumRezervacije.Name = "datumRezervacije";
            this.datumRezervacije.Size = new System.Drawing.Size(38, 13);
            this.datumRezervacije.TabIndex = 4;
            this.datumRezervacije.Text = "Datum";
            // 
            // vrijemeRezervacije
            // 
            this.vrijemeRezervacije.AutoSize = true;
            this.vrijemeRezervacije.Location = new System.Drawing.Point(52, 235);
            this.vrijemeRezervacije.Name = "vrijemeRezervacije";
            this.vrijemeRezervacije.Size = new System.Drawing.Size(41, 13);
            this.vrijemeRezervacije.TabIndex = 5;
            this.vrijemeRezervacije.Text = "Vrijeme";
            // 
            // adresaClana
            // 
            this.adresaClana.AutoSize = true;
            this.adresaClana.Location = new System.Drawing.Point(52, 118);
            this.adresaClana.Name = "adresaClana";
            this.adresaClana.Size = new System.Drawing.Size(40, 13);
            this.adresaClana.TabIndex = 6;
            this.adresaClana.Text = "Adresa";
            this.adresaClana.Click += new System.EventHandler(this.label5_Click);
            // 
            // kontaktBroj
            // 
            this.kontaktBroj.AutoSize = true;
            this.kontaktBroj.Location = new System.Drawing.Point(52, 273);
            this.kontaktBroj.Name = "kontaktBroj";
            this.kontaktBroj.Size = new System.Drawing.Size(44, 13);
            this.kontaktBroj.TabIndex = 7;
            this.kontaktBroj.Text = "Kontakt";
            this.kontaktBroj.Click += new System.EventHandler(this.label6_Click);
            // 
            // prezimeUpis
            // 
            this.prezimeUpis.Location = new System.Drawing.Point(118, 69);
            this.prezimeUpis.Name = "prezimeUpis";
            this.prezimeUpis.Size = new System.Drawing.Size(189, 20);
            this.prezimeUpis.TabIndex = 8;
            // 
            // adresaUpis
            // 
            this.adresaUpis.Location = new System.Drawing.Point(118, 111);
            this.adresaUpis.Name = "adresaUpis";
            this.adresaUpis.Size = new System.Drawing.Size(189, 20);
            this.adresaUpis.TabIndex = 9;
            // 
            // sportIzbor
            // 
            this.sportIzbor.FormattingEnabled = true;
            this.sportIzbor.Location = new System.Drawing.Point(118, 149);
            this.sportIzbor.Name = "sportIzbor";
            this.sportIzbor.Size = new System.Drawing.Size(189, 21);
            this.sportIzbor.TabIndex = 10;
            // 
            // datumIzbor
            // 
            this.datumIzbor.Location = new System.Drawing.Point(118, 188);
            this.datumIzbor.Name = "datumIzbor";
            this.datumIzbor.Size = new System.Drawing.Size(189, 20);
            this.datumIzbor.TabIndex = 11;
            // 
            // vrijemeUpis
            // 
            this.vrijemeUpis.Location = new System.Drawing.Point(118, 228);
            this.vrijemeUpis.Name = "vrijemeUpis";
            this.vrijemeUpis.Size = new System.Drawing.Size(189, 20);
            this.vrijemeUpis.TabIndex = 12;
            // 
            // kontaktUpis
            // 
            this.kontaktUpis.Location = new System.Drawing.Point(118, 266);
            this.kontaktUpis.Name = "kontaktUpis";
            this.kontaktUpis.Size = new System.Drawing.Size(189, 20);
            this.kontaktUpis.TabIndex = 13;
            // 
            // pohraniClana
            // 
            this.pohraniClana.Location = new System.Drawing.Point(232, 318);
            this.pohraniClana.Name = "pohraniClana";
            this.pohraniClana.Size = new System.Drawing.Size(75, 23);
            this.pohraniClana.TabIndex = 14;
            this.pohraniClana.Text = "Pohrani";
            this.pohraniClana.UseVisualStyleBackColor = true;
            // 
            // NovaRezervacija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 362);
            this.Controls.Add(this.pohraniClana);
            this.Controls.Add(this.kontaktUpis);
            this.Controls.Add(this.vrijemeUpis);
            this.Controls.Add(this.datumIzbor);
            this.Controls.Add(this.sportIzbor);
            this.Controls.Add(this.adresaUpis);
            this.Controls.Add(this.prezimeUpis);
            this.Controls.Add(this.kontaktBroj);
            this.Controls.Add(this.adresaClana);
            this.Controls.Add(this.vrijemeRezervacije);
            this.Controls.Add(this.datumRezervacije);
            this.Controls.Add(this.vrstaSporta);
            this.Controls.Add(this.prezimeClana);
            this.Controls.Add(this.imeUpis);
            this.Controls.Add(this.imeClana);
            this.Name = "NovaRezervacija";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nova Rezervacija";
            this.Load += new System.EventHandler(this.NovaRezervacija_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label imeClana;
        private System.Windows.Forms.TextBox imeUpis;
        private System.Windows.Forms.Label prezimeClana;
        private System.Windows.Forms.Label vrstaSporta;
        private System.Windows.Forms.Label datumRezervacije;
        private System.Windows.Forms.Label vrijemeRezervacije;
        private System.Windows.Forms.Label adresaClana;
        private System.Windows.Forms.Label kontaktBroj;
        private System.Windows.Forms.TextBox prezimeUpis;
        private System.Windows.Forms.TextBox adresaUpis;
        private System.Windows.Forms.ComboBox sportIzbor;
        private System.Windows.Forms.DateTimePicker datumIzbor;
        private System.Windows.Forms.TextBox vrijemeUpis;
        private System.Windows.Forms.TextBox kontaktUpis;
        private System.Windows.Forms.Button pohraniClana;
    }
}
﻿namespace projekt_appGrade
{
    partial class RacunForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ispisRacuna = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.zaposlenik = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vrijemeIzdavanja = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oibIzdavatelja = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresaIzdavatelja = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iznos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iznosPoreza = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.izdatiRacun = new System.Windows.Forms.Button();
            this.racunIspis = new System.Windows.Forms.Button();
            this.cjenikUsluga = new System.Windows.Forms.Button();
            this.odustaniRacun = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.stavka = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ispisRacuna)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // ispisRacuna
            // 
            this.ispisRacuna.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ispisRacuna.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.zaposlenik,
            this.vrijemeIzdavanja,
            this.oibIzdavatelja,
            this.adresaIzdavatelja,
            this.iznos,
            this.iznosPoreza,
            this.clan});
            this.ispisRacuna.Location = new System.Drawing.Point(12, 12);
            this.ispisRacuna.Name = "ispisRacuna";
            this.ispisRacuna.Size = new System.Drawing.Size(860, 269);
            this.ispisRacuna.TabIndex = 0;
            // 
            // id
            // 
            this.id.HeaderText = "ID";
            this.id.Name = "id";
            // 
            // zaposlenik
            // 
            this.zaposlenik.HeaderText = "Zaposlenik";
            this.zaposlenik.Name = "zaposlenik";
            // 
            // vrijemeIzdavanja
            // 
            this.vrijemeIzdavanja.HeaderText = "Vrijeme izdavanja";
            this.vrijemeIzdavanja.Name = "vrijemeIzdavanja";
            // 
            // oibIzdavatelja
            // 
            this.oibIzdavatelja.HeaderText = "OIB izdavatelja";
            this.oibIzdavatelja.Name = "oibIzdavatelja";
            // 
            // adresaIzdavatelja
            // 
            this.adresaIzdavatelja.HeaderText = "Adresa izdavatelja";
            this.adresaIzdavatelja.Name = "adresaIzdavatelja";
            // 
            // iznos
            // 
            this.iznos.HeaderText = "Iznos";
            this.iznos.Name = "iznos";
            // 
            // iznosPoreza
            // 
            this.iznosPoreza.HeaderText = "Iznos poreza";
            this.iznosPoreza.Name = "iznosPoreza";
            // 
            // clan
            // 
            this.clan.HeaderText = "Član";
            this.clan.Name = "clan";
            // 
            // izdatiRacun
            // 
            this.izdatiRacun.Location = new System.Drawing.Point(635, 302);
            this.izdatiRacun.Name = "izdatiRacun";
            this.izdatiRacun.Size = new System.Drawing.Size(75, 23);
            this.izdatiRacun.TabIndex = 1;
            this.izdatiRacun.Text = "Izdaj novi";
            this.izdatiRacun.UseVisualStyleBackColor = true;
            this.izdatiRacun.Click += new System.EventHandler(this.izdatiRacun_Click);
            // 
            // racunIspis
            // 
            this.racunIspis.Location = new System.Drawing.Point(716, 302);
            this.racunIspis.Name = "racunIspis";
            this.racunIspis.Size = new System.Drawing.Size(75, 23);
            this.racunIspis.TabIndex = 2;
            this.racunIspis.Text = "Ispis računa";
            this.racunIspis.UseVisualStyleBackColor = true;
            this.racunIspis.Click += new System.EventHandler(this.racunIspis_Click);
            // 
            // cjenikUsluga
            // 
            this.cjenikUsluga.Location = new System.Drawing.Point(716, 396);
            this.cjenikUsluga.Name = "cjenikUsluga";
            this.cjenikUsluga.Size = new System.Drawing.Size(90, 35);
            this.cjenikUsluga.TabIndex = 3;
            this.cjenikUsluga.Text = "Cjenik";
            this.cjenikUsluga.UseVisualStyleBackColor = true;
            this.cjenikUsluga.Click += new System.EventHandler(this.cjenikUsluga_Click);
            // 
            // odustaniRacun
            // 
            this.odustaniRacun.Location = new System.Drawing.Point(797, 302);
            this.odustaniRacun.Name = "odustaniRacun";
            this.odustaniRacun.Size = new System.Drawing.Size(75, 23);
            this.odustaniRacun.TabIndex = 4;
            this.odustaniRacun.Text = "Odustani";
            this.odustaniRacun.UseVisualStyleBackColor = true;
            this.odustaniRacun.Click += new System.EventHandler(this.odustaniRacun_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stavka});
            this.dataGridView1.Location = new System.Drawing.Point(168, 302);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(447, 183);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // stavka
            // 
            this.stavka.HeaderText = "Stavka";
            this.stavka.Name = "stavka";
            this.stavka.Width = 400;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(65, 302);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Stavke računa:";
            // 
            // RacunForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 515);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.odustaniRacun);
            this.Controls.Add(this.cjenikUsluga);
            this.Controls.Add(this.racunIspis);
            this.Controls.Add(this.izdatiRacun);
            this.Controls.Add(this.ispisRacuna);
            this.Name = "RacunForma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Račun";
            this.Load += new System.EventHandler(this.RacunForma_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ispisRacuna)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ispisRacuna;
        private System.Windows.Forms.Button izdatiRacun;
        private System.Windows.Forms.Button racunIspis;
        private System.Windows.Forms.Button cjenikUsluga;
        private System.Windows.Forms.Button odustaniRacun;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn zaposlenik;
        private System.Windows.Forms.DataGridViewTextBoxColumn vrijemeIzdavanja;
        private System.Windows.Forms.DataGridViewTextBoxColumn oibIzdavatelja;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresaIzdavatelja;
        private System.Windows.Forms.DataGridViewTextBoxColumn iznos;
        private System.Windows.Forms.DataGridViewTextBoxColumn iznosPoreza;
        private System.Windows.Forms.DataGridViewTextBoxColumn clan;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn stavka;
        private System.Windows.Forms.Label label1;
    }
}
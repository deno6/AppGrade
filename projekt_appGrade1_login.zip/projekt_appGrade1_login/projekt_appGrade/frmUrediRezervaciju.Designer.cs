﻿namespace projekt_appGrade
{
    partial class UrediRezervaciju
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pohraniEdit = new System.Windows.Forms.Button();
            this.kontaktEdit = new System.Windows.Forms.TextBox();
            this.vrijemeEdit = new System.Windows.Forms.TextBox();
            this.datumEdit = new System.Windows.Forms.DateTimePicker();
            this.sportEdit = new System.Windows.Forms.ComboBox();
            this.adresaEdit = new System.Windows.Forms.TextBox();
            this.prezimeEdit = new System.Windows.Forms.TextBox();
            this.kontaktCl = new System.Windows.Forms.Label();
            this.adresaCl = new System.Windows.Forms.Label();
            this.vrijemeCl = new System.Windows.Forms.Label();
            this.datumCl = new System.Windows.Forms.Label();
            this.sportCl = new System.Windows.Forms.Label();
            this.prezimeCl = new System.Windows.Forms.Label();
            this.imeEdit = new System.Windows.Forms.TextBox();
            this.imeCl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pohraniEdit
            // 
            this.pohraniEdit.Location = new System.Drawing.Point(243, 332);
            this.pohraniEdit.Name = "pohraniEdit";
            this.pohraniEdit.Size = new System.Drawing.Size(75, 23);
            this.pohraniEdit.TabIndex = 29;
            this.pohraniEdit.Text = "Pohrani";
            this.pohraniEdit.UseVisualStyleBackColor = true;
            // 
            // kontaktEdit
            // 
            this.kontaktEdit.Location = new System.Drawing.Point(129, 280);
            this.kontaktEdit.Name = "kontaktEdit";
            this.kontaktEdit.Size = new System.Drawing.Size(189, 20);
            this.kontaktEdit.TabIndex = 28;
            // 
            // vrijemeEdit
            // 
            this.vrijemeEdit.Location = new System.Drawing.Point(129, 242);
            this.vrijemeEdit.Name = "vrijemeEdit";
            this.vrijemeEdit.Size = new System.Drawing.Size(189, 20);
            this.vrijemeEdit.TabIndex = 27;
            // 
            // datumEdit
            // 
            this.datumEdit.Location = new System.Drawing.Point(129, 202);
            this.datumEdit.Name = "datumEdit";
            this.datumEdit.Size = new System.Drawing.Size(189, 20);
            this.datumEdit.TabIndex = 26;
            // 
            // sportEdit
            // 
            this.sportEdit.FormattingEnabled = true;
            this.sportEdit.Location = new System.Drawing.Point(129, 163);
            this.sportEdit.Name = "sportEdit";
            this.sportEdit.Size = new System.Drawing.Size(189, 21);
            this.sportEdit.TabIndex = 25;
            // 
            // adresaEdit
            // 
            this.adresaEdit.Location = new System.Drawing.Point(129, 125);
            this.adresaEdit.Name = "adresaEdit";
            this.adresaEdit.Size = new System.Drawing.Size(189, 20);
            this.adresaEdit.TabIndex = 24;
            // 
            // prezimeEdit
            // 
            this.prezimeEdit.Location = new System.Drawing.Point(129, 83);
            this.prezimeEdit.Name = "prezimeEdit";
            this.prezimeEdit.Size = new System.Drawing.Size(189, 20);
            this.prezimeEdit.TabIndex = 23;
            // 
            // kontaktCl
            // 
            this.kontaktCl.AutoSize = true;
            this.kontaktCl.Location = new System.Drawing.Point(63, 287);
            this.kontaktCl.Name = "kontaktCl";
            this.kontaktCl.Size = new System.Drawing.Size(44, 13);
            this.kontaktCl.TabIndex = 22;
            this.kontaktCl.Text = "Kontakt";
            // 
            // adresaCl
            // 
            this.adresaCl.AutoSize = true;
            this.adresaCl.Location = new System.Drawing.Point(63, 132);
            this.adresaCl.Name = "adresaCl";
            this.adresaCl.Size = new System.Drawing.Size(40, 13);
            this.adresaCl.TabIndex = 21;
            this.adresaCl.Text = "Adresa";
            // 
            // vrijemeCl
            // 
            this.vrijemeCl.AutoSize = true;
            this.vrijemeCl.Location = new System.Drawing.Point(63, 249);
            this.vrijemeCl.Name = "vrijemeCl";
            this.vrijemeCl.Size = new System.Drawing.Size(41, 13);
            this.vrijemeCl.TabIndex = 20;
            this.vrijemeCl.Text = "Vrijeme";
            // 
            // datumCl
            // 
            this.datumCl.AutoSize = true;
            this.datumCl.Location = new System.Drawing.Point(63, 210);
            this.datumCl.Name = "datumCl";
            this.datumCl.Size = new System.Drawing.Size(38, 13);
            this.datumCl.TabIndex = 19;
            this.datumCl.Text = "Datum";
            // 
            // sportCl
            // 
            this.sportCl.AutoSize = true;
            this.sportCl.Location = new System.Drawing.Point(63, 171);
            this.sportCl.Name = "sportCl";
            this.sportCl.Size = new System.Drawing.Size(32, 13);
            this.sportCl.TabIndex = 18;
            this.sportCl.Text = "Sport";
            // 
            // prezimeCl
            // 
            this.prezimeCl.AutoSize = true;
            this.prezimeCl.Location = new System.Drawing.Point(63, 90);
            this.prezimeCl.Name = "prezimeCl";
            this.prezimeCl.Size = new System.Drawing.Size(44, 13);
            this.prezimeCl.TabIndex = 17;
            this.prezimeCl.Text = "Prezime";
            // 
            // imeEdit
            // 
            this.imeEdit.Location = new System.Drawing.Point(129, 45);
            this.imeEdit.Name = "imeEdit";
            this.imeEdit.Size = new System.Drawing.Size(189, 20);
            this.imeEdit.TabIndex = 16;
            // 
            // imeCl
            // 
            this.imeCl.AutoSize = true;
            this.imeCl.Location = new System.Drawing.Point(63, 48);
            this.imeCl.Name = "imeCl";
            this.imeCl.Size = new System.Drawing.Size(24, 13);
            this.imeCl.TabIndex = 15;
            this.imeCl.Text = "Ime";
            // 
            // UrediRezervaciju
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 394);
            this.Controls.Add(this.pohraniEdit);
            this.Controls.Add(this.kontaktEdit);
            this.Controls.Add(this.vrijemeEdit);
            this.Controls.Add(this.datumEdit);
            this.Controls.Add(this.sportEdit);
            this.Controls.Add(this.adresaEdit);
            this.Controls.Add(this.prezimeEdit);
            this.Controls.Add(this.kontaktCl);
            this.Controls.Add(this.adresaCl);
            this.Controls.Add(this.vrijemeCl);
            this.Controls.Add(this.datumCl);
            this.Controls.Add(this.sportCl);
            this.Controls.Add(this.prezimeCl);
            this.Controls.Add(this.imeEdit);
            this.Controls.Add(this.imeCl);
            this.Name = "UrediRezervaciju";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Uređivanje rezervacije";
            this.Load += new System.EventHandler(this.urediRezervaciju_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button pohraniEdit;
        private System.Windows.Forms.TextBox kontaktEdit;
        private System.Windows.Forms.TextBox vrijemeEdit;
        private System.Windows.Forms.DateTimePicker datumEdit;
        private System.Windows.Forms.ComboBox sportEdit;
        private System.Windows.Forms.TextBox adresaEdit;
        private System.Windows.Forms.TextBox prezimeEdit;
        private System.Windows.Forms.Label kontaktCl;
        private System.Windows.Forms.Label adresaCl;
        private System.Windows.Forms.Label vrijemeCl;
        private System.Windows.Forms.Label datumCl;
        private System.Windows.Forms.Label sportCl;
        private System.Windows.Forms.Label prezimeCl;
        private System.Windows.Forms.TextBox imeEdit;
        private System.Windows.Forms.Label imeCl;
    }
}
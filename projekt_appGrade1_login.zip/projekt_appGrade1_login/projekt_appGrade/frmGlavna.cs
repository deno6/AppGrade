﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt_appGrade
{
    public partial class GlavnaForma : Form
    {
        public GlavnaForma()
        {
            InitializeComponent();
        }

        private void dodajNovogToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void računToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RacunForma racunForma = new RacunForma();
            racunForma.Show();
        }

        private void rezervacijeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IspisRezervacije ispis = new IspisRezervacije();
            ispis.Show();
        }

        private void članoviToolStripMenuItem_MouseUp(object sender, MouseEventArgs e)
        {
            frmClan clanovi = new frmClan();
            clanovi.Show();
        }

        private void GlavnaForma_Load(object sender, EventArgs e)
        {

        }

        private void sportToolStripMenuItem_MouseUp(object sender, MouseEventArgs e)
        {
            frmSportOprema sportOprema = new frmSportOprema();
            sportOprema.Show();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt_appGrade
{
    public partial class RacunForma : Form
    {
        public RacunForma()
        {
            InitializeComponent();
        }

        private void izdatiRacun_Click(object sender, EventArgs e)
        {
            NoviRacun noviRacun = new NoviRacun();
            noviRacun.Show();
        }

        private void RacunForma_Load(object sender, EventArgs e)
        {

            //this.ispisIzvjestaja.RefreshReport();
        }

        private void racunIspis_Click(object sender, EventArgs e)
        {
            IspisRacun ispisRacun = new IspisRacun();
            ispisRacun.Show();
        }

        private void cjenikUsluga_Click(object sender, EventArgs e)
        {
            CjenikForma cjenikForma = new CjenikForma();
            cjenikForma.Show();
        }

        private void odustaniRacun_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

﻿namespace projekt_appGrade
{
    partial class NoviRacun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.brojRacuna = new System.Windows.Forms.Label();
            this.datumRacuna = new System.Windows.Forms.Label();
            this.oibRacuna = new System.Windows.Forms.Label();
            this.adresaRacun = new System.Windows.Forms.Label();
            this.iznosRacun = new System.Windows.Forms.Label();
            this.pdvRacun = new System.Windows.Forms.Label();
            this.racunStavke = new System.Windows.Forms.Label();
            this.ukupnoRacun = new System.Windows.Forms.Label();
            this.racunStavka = new System.Windows.Forms.ListView();
            this.racunKolicina = new System.Windows.Forms.Label();
            this.kolicinaRacun = new System.Windows.Forms.ListView();
            this.upisRacun = new System.Windows.Forms.TextBox();
            this.datumRacun = new System.Windows.Forms.DateTimePicker();
            this.racunOib = new System.Windows.Forms.TextBox();
            this.racunAdresa = new System.Windows.Forms.TextBox();
            this.racunIznos = new System.Windows.Forms.TextBox();
            this.racunPdv = new System.Windows.Forms.TextBox();
            this.racunUkupno = new System.Windows.Forms.TextBox();
            this.spremiRacun = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // brojRacuna
            // 
            this.brojRacuna.AutoSize = true;
            this.brojRacuna.Location = new System.Drawing.Point(12, 18);
            this.brojRacuna.Name = "brojRacuna";
            this.brojRacuna.Size = new System.Drawing.Size(61, 13);
            this.brojRacuna.TabIndex = 0;
            this.brojRacuna.Text = "Broj računa";
            this.brojRacuna.Click += new System.EventHandler(this.label1_Click);
            // 
            // datumRacuna
            // 
            this.datumRacuna.AutoSize = true;
            this.datumRacuna.Location = new System.Drawing.Point(12, 53);
            this.datumRacuna.Name = "datumRacuna";
            this.datumRacuna.Size = new System.Drawing.Size(78, 13);
            this.datumRacuna.TabIndex = 1;
            this.datumRacuna.Text = "Vrijeme i datum";
            // 
            // oibRacuna
            // 
            this.oibRacuna.AutoSize = true;
            this.oibRacuna.Location = new System.Drawing.Point(12, 90);
            this.oibRacuna.Name = "oibRacuna";
            this.oibRacuna.Size = new System.Drawing.Size(25, 13);
            this.oibRacuna.TabIndex = 2;
            this.oibRacuna.Text = "OIB";
            // 
            // adresaRacun
            // 
            this.adresaRacun.AutoSize = true;
            this.adresaRacun.Location = new System.Drawing.Point(12, 128);
            this.adresaRacun.Name = "adresaRacun";
            this.adresaRacun.Size = new System.Drawing.Size(40, 13);
            this.adresaRacun.TabIndex = 3;
            this.adresaRacun.Text = "Adresa";
            // 
            // iznosRacun
            // 
            this.iznosRacun.AutoSize = true;
            this.iznosRacun.Location = new System.Drawing.Point(12, 315);
            this.iznosRacun.Name = "iznosRacun";
            this.iznosRacun.Size = new System.Drawing.Size(32, 13);
            this.iznosRacun.TabIndex = 4;
            this.iznosRacun.Text = "Iznos";
            // 
            // pdvRacun
            // 
            this.pdvRacun.AutoSize = true;
            this.pdvRacun.Location = new System.Drawing.Point(12, 352);
            this.pdvRacun.Name = "pdvRacun";
            this.pdvRacun.Size = new System.Drawing.Size(29, 13);
            this.pdvRacun.TabIndex = 5;
            this.pdvRacun.Text = "PDV";
            // 
            // racunStavke
            // 
            this.racunStavke.AutoSize = true;
            this.racunStavke.Location = new System.Drawing.Point(279, 11);
            this.racunStavke.Name = "racunStavke";
            this.racunStavke.Size = new System.Drawing.Size(77, 13);
            this.racunStavke.TabIndex = 6;
            this.racunStavke.Text = "Stavke računa";
            // 
            // ukupnoRacun
            // 
            this.ukupnoRacun.AutoSize = true;
            this.ukupnoRacun.Location = new System.Drawing.Point(12, 389);
            this.ukupnoRacun.Name = "ukupnoRacun";
            this.ukupnoRacun.Size = new System.Drawing.Size(72, 13);
            this.ukupnoRacun.TabIndex = 7;
            this.ukupnoRacun.Text = "Ukupan iznos";
            // 
            // racunStavka
            // 
            this.racunStavka.Location = new System.Drawing.Point(282, 41);
            this.racunStavka.Name = "racunStavka";
            this.racunStavka.Size = new System.Drawing.Size(285, 361);
            this.racunStavka.TabIndex = 8;
            this.racunStavka.UseCompatibleStateImageBehavior = false;
            // 
            // racunKolicina
            // 
            this.racunKolicina.AutoSize = true;
            this.racunKolicina.Location = new System.Drawing.Point(570, 11);
            this.racunKolicina.Name = "racunKolicina";
            this.racunKolicina.Size = new System.Drawing.Size(44, 13);
            this.racunKolicina.TabIndex = 9;
            this.racunKolicina.Text = "Količina";
            // 
            // kolicinaRacun
            // 
            this.kolicinaRacun.Location = new System.Drawing.Point(573, 41);
            this.kolicinaRacun.Name = "kolicinaRacun";
            this.kolicinaRacun.Size = new System.Drawing.Size(79, 361);
            this.kolicinaRacun.TabIndex = 10;
            this.kolicinaRacun.UseCompatibleStateImageBehavior = false;
            // 
            // upisRacun
            // 
            this.upisRacun.Location = new System.Drawing.Point(105, 15);
            this.upisRacun.Name = "upisRacun";
            this.upisRacun.Size = new System.Drawing.Size(148, 20);
            this.upisRacun.TabIndex = 11;
            // 
            // datumRacun
            // 
            this.datumRacun.Location = new System.Drawing.Point(105, 45);
            this.datumRacun.Name = "datumRacun";
            this.datumRacun.Size = new System.Drawing.Size(148, 20);
            this.datumRacun.TabIndex = 12;
            // 
            // racunOib
            // 
            this.racunOib.Location = new System.Drawing.Point(105, 82);
            this.racunOib.Name = "racunOib";
            this.racunOib.Size = new System.Drawing.Size(148, 20);
            this.racunOib.TabIndex = 13;
            // 
            // racunAdresa
            // 
            this.racunAdresa.Location = new System.Drawing.Point(105, 121);
            this.racunAdresa.Name = "racunAdresa";
            this.racunAdresa.Size = new System.Drawing.Size(148, 20);
            this.racunAdresa.TabIndex = 14;
            // 
            // racunIznos
            // 
            this.racunIznos.Location = new System.Drawing.Point(105, 308);
            this.racunIznos.Name = "racunIznos";
            this.racunIznos.Size = new System.Drawing.Size(148, 20);
            this.racunIznos.TabIndex = 15;
            // 
            // racunPdv
            // 
            this.racunPdv.Location = new System.Drawing.Point(105, 345);
            this.racunPdv.Name = "racunPdv";
            this.racunPdv.Size = new System.Drawing.Size(148, 20);
            this.racunPdv.TabIndex = 16;
            // 
            // racunUkupno
            // 
            this.racunUkupno.Location = new System.Drawing.Point(105, 382);
            this.racunUkupno.Name = "racunUkupno";
            this.racunUkupno.Size = new System.Drawing.Size(148, 20);
            this.racunUkupno.TabIndex = 17;
            // 
            // spremiRacun
            // 
            this.spremiRacun.Location = new System.Drawing.Point(548, 425);
            this.spremiRacun.Name = "spremiRacun";
            this.spremiRacun.Size = new System.Drawing.Size(104, 23);
            this.spremiRacun.TabIndex = 18;
            this.spremiRacun.Text = "Spremi i ispiši";
            this.spremiRacun.UseVisualStyleBackColor = true;
            // 
            // NoviRacun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 471);
            this.Controls.Add(this.spremiRacun);
            this.Controls.Add(this.racunUkupno);
            this.Controls.Add(this.racunPdv);
            this.Controls.Add(this.racunIznos);
            this.Controls.Add(this.racunAdresa);
            this.Controls.Add(this.racunOib);
            this.Controls.Add(this.datumRacun);
            this.Controls.Add(this.upisRacun);
            this.Controls.Add(this.kolicinaRacun);
            this.Controls.Add(this.racunKolicina);
            this.Controls.Add(this.racunStavka);
            this.Controls.Add(this.ukupnoRacun);
            this.Controls.Add(this.racunStavke);
            this.Controls.Add(this.pdvRacun);
            this.Controls.Add(this.iznosRacun);
            this.Controls.Add(this.adresaRacun);
            this.Controls.Add(this.oibRacuna);
            this.Controls.Add(this.datumRacuna);
            this.Controls.Add(this.brojRacuna);
            this.Name = "NoviRacun";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Novi račun";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label brojRacuna;
        private System.Windows.Forms.Label datumRacuna;
        private System.Windows.Forms.Label oibRacuna;
        private System.Windows.Forms.Label adresaRacun;
        private System.Windows.Forms.Label iznosRacun;
        private System.Windows.Forms.Label pdvRacun;
        private System.Windows.Forms.Label racunStavke;
        private System.Windows.Forms.Label ukupnoRacun;
        private System.Windows.Forms.ListView racunStavka;
        private System.Windows.Forms.Label racunKolicina;
        private System.Windows.Forms.ListView kolicinaRacun;
        private System.Windows.Forms.TextBox upisRacun;
        private System.Windows.Forms.DateTimePicker datumRacun;
        private System.Windows.Forms.TextBox racunOib;
        private System.Windows.Forms.TextBox racunAdresa;
        private System.Windows.Forms.TextBox racunIznos;
        private System.Windows.Forms.TextBox racunPdv;
        private System.Windows.Forms.TextBox racunUkupno;
        private System.Windows.Forms.Button spremiRacun;
    }
}
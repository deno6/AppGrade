﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt_appGrade
{
    public partial class IspisRacun : Form
    {
        public IspisRacun()
        {
            InitializeComponent();
        }

        private void IspisRacun_Load(object sender, EventArgs e)
        {

            this.ispisIzvjestaja.RefreshReport();
        }

        private void odustaniIspis_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ispisIzvjestaja_Load(object sender, EventArgs e)
        {

        }
    }
}

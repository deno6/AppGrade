﻿namespace projekt_appGrade
{
    partial class IspisRezervacije
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RezervacijePregled = new System.Windows.Forms.DataGridView();
            this.dodatiRezervaciju = new System.Windows.Forms.Button();
            this.ureditiRezervaciju = new System.Windows.Forms.Button();
            this.brisatiRezervacije = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.RezervacijePregled)).BeginInit();
            this.SuspendLayout();
            // 
            // RezervacijePregled
            // 
            this.RezervacijePregled.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RezervacijePregled.Location = new System.Drawing.Point(12, 12);
            this.RezervacijePregled.Name = "RezervacijePregled";
            this.RezervacijePregled.Size = new System.Drawing.Size(688, 345);
            this.RezervacijePregled.TabIndex = 0;
            // 
            // dodatiRezervaciju
            // 
            this.dodatiRezervaciju.Location = new System.Drawing.Point(425, 377);
            this.dodatiRezervaciju.Name = "dodatiRezervaciju";
            this.dodatiRezervaciju.Size = new System.Drawing.Size(75, 23);
            this.dodatiRezervaciju.TabIndex = 1;
            this.dodatiRezervaciju.Text = "Dodaj novu";
            this.dodatiRezervaciju.UseVisualStyleBackColor = true;
            this.dodatiRezervaciju.Click += new System.EventHandler(this.dodatiRezervaciju_Click);
            // 
            // ureditiRezervaciju
            // 
            this.ureditiRezervaciju.Location = new System.Drawing.Point(587, 377);
            this.ureditiRezervaciju.Name = "ureditiRezervaciju";
            this.ureditiRezervaciju.Size = new System.Drawing.Size(75, 23);
            this.ureditiRezervaciju.TabIndex = 3;
            this.ureditiRezervaciju.Text = "Uredi";
            this.ureditiRezervaciju.UseVisualStyleBackColor = true;
            this.ureditiRezervaciju.Click += new System.EventHandler(this.ureditiRezervaciju_Click);
            // 
            // brisatiRezervacije
            // 
            this.brisatiRezervacije.Location = new System.Drawing.Point(506, 377);
            this.brisatiRezervacije.Name = "brisatiRezervacije";
            this.brisatiRezervacije.Size = new System.Drawing.Size(75, 23);
            this.brisatiRezervacije.TabIndex = 4;
            this.brisatiRezervacije.Text = "Obriši";
            this.brisatiRezervacije.UseVisualStyleBackColor = true;
            // 
            // IspisRezervacije
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 415);
            this.Controls.Add(this.brisatiRezervacije);
            this.Controls.Add(this.ureditiRezervaciju);
            this.Controls.Add(this.dodatiRezervaciju);
            this.Controls.Add(this.RezervacijePregled);
            this.Name = "IspisRezervacije";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rezervacije";
            this.Load += new System.EventHandler(this.brisanjeRezervacije_Load);
            ((System.ComponentModel.ISupportInitialize)(this.RezervacijePregled)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView RezervacijePregled;
        private System.Windows.Forms.Button dodatiRezervaciju;
        private System.Windows.Forms.Button ureditiRezervaciju;
        private System.Windows.Forms.Button brisatiRezervacije;
    }
}
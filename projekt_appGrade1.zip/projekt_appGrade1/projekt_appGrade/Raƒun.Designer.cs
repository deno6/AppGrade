﻿namespace projekt_appGrade
{
    partial class RacunForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ispisRacuna = new System.Windows.Forms.DataGridView();
            this.izdatiRacun = new System.Windows.Forms.Button();
            this.racunIspis = new System.Windows.Forms.Button();
            this.cjenikUsluga = new System.Windows.Forms.Button();
            this.odustaniRacun = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ispisRacuna)).BeginInit();
            this.SuspendLayout();
            // 
            // ispisRacuna
            // 
            this.ispisRacuna.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ispisRacuna.Location = new System.Drawing.Point(12, 12);
            this.ispisRacuna.Name = "ispisRacuna";
            this.ispisRacuna.Size = new System.Drawing.Size(633, 327);
            this.ispisRacuna.TabIndex = 0;
            // 
            // izdatiRacun
            // 
            this.izdatiRacun.Location = new System.Drawing.Point(390, 367);
            this.izdatiRacun.Name = "izdatiRacun";
            this.izdatiRacun.Size = new System.Drawing.Size(75, 23);
            this.izdatiRacun.TabIndex = 1;
            this.izdatiRacun.Text = "Izdaj novi";
            this.izdatiRacun.UseVisualStyleBackColor = true;
            this.izdatiRacun.Click += new System.EventHandler(this.izdatiRacun_Click);
            // 
            // racunIspis
            // 
            this.racunIspis.Location = new System.Drawing.Point(471, 367);
            this.racunIspis.Name = "racunIspis";
            this.racunIspis.Size = new System.Drawing.Size(75, 23);
            this.racunIspis.TabIndex = 2;
            this.racunIspis.Text = "Ispis računa";
            this.racunIspis.UseVisualStyleBackColor = true;
            this.racunIspis.Click += new System.EventHandler(this.racunIspis_Click);
            // 
            // cjenikUsluga
            // 
            this.cjenikUsluga.Location = new System.Drawing.Point(23, 367);
            this.cjenikUsluga.Name = "cjenikUsluga";
            this.cjenikUsluga.Size = new System.Drawing.Size(75, 23);
            this.cjenikUsluga.TabIndex = 3;
            this.cjenikUsluga.Text = "Cjenik";
            this.cjenikUsluga.UseVisualStyleBackColor = true;
            this.cjenikUsluga.Click += new System.EventHandler(this.cjenikUsluga_Click);
            // 
            // odustaniRacun
            // 
            this.odustaniRacun.Location = new System.Drawing.Point(553, 366);
            this.odustaniRacun.Name = "odustaniRacun";
            this.odustaniRacun.Size = new System.Drawing.Size(75, 23);
            this.odustaniRacun.TabIndex = 4;
            this.odustaniRacun.Text = "Odustani";
            this.odustaniRacun.UseVisualStyleBackColor = true;
            this.odustaniRacun.Click += new System.EventHandler(this.odustaniRacun_Click);
            // 
            // RacunForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 414);
            this.Controls.Add(this.odustaniRacun);
            this.Controls.Add(this.cjenikUsluga);
            this.Controls.Add(this.racunIspis);
            this.Controls.Add(this.izdatiRacun);
            this.Controls.Add(this.ispisRacuna);
            this.Name = "RacunForma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Račun";
            this.Load += new System.EventHandler(this.RacunForma_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ispisRacuna)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView ispisRacuna;
        private System.Windows.Forms.Button izdatiRacun;
        private System.Windows.Forms.Button racunIspis;
        private System.Windows.Forms.Button cjenikUsluga;
        private System.Windows.Forms.Button odustaniRacun;
    }
}
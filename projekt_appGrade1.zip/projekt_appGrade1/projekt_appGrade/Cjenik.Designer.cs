﻿namespace projekt_appGrade
{
    partial class CjenikForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cjenikPrikaz = new System.Windows.Forms.DataGridView();
            this.zatvoriCjenik = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cjenikPrikaz)).BeginInit();
            this.SuspendLayout();
            // 
            // cjenikPrikaz
            // 
            this.cjenikPrikaz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cjenikPrikaz.Location = new System.Drawing.Point(13, 24);
            this.cjenikPrikaz.Name = "cjenikPrikaz";
            this.cjenikPrikaz.Size = new System.Drawing.Size(528, 407);
            this.cjenikPrikaz.TabIndex = 0;
            // 
            // zatvoriCjenik
            // 
            this.zatvoriCjenik.Location = new System.Drawing.Point(444, 448);
            this.zatvoriCjenik.Name = "zatvoriCjenik";
            this.zatvoriCjenik.Size = new System.Drawing.Size(75, 23);
            this.zatvoriCjenik.TabIndex = 1;
            this.zatvoriCjenik.Text = "Zatvori";
            this.zatvoriCjenik.UseVisualStyleBackColor = true;
            this.zatvoriCjenik.Click += new System.EventHandler(this.zatvoriCjenik_Click);
            // 
            // CjenikForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 492);
            this.Controls.Add(this.zatvoriCjenik);
            this.Controls.Add(this.cjenikPrikaz);
            this.Name = "CjenikForma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cjenik";
            ((System.ComponentModel.ISupportInitialize)(this.cjenikPrikaz)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView cjenikPrikaz;
        private System.Windows.Forms.Button zatvoriCjenik;
    }
}
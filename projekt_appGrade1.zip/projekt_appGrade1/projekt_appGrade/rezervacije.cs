﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt_appGrade
{
    public partial class IspisRezervacije : Form
    {
        public IspisRezervacije()
        {
            InitializeComponent();
        }

        private void brisanjeRezervacije_Load(object sender, EventArgs e)
        {

        }

        private void dodatiRezervaciju_Click(object sender, EventArgs e)
        {
            NovaRezervacija novaRezervacija = new NovaRezervacija();
            novaRezervacija.Show();
        }

        private void ureditiRezervaciju_Click(object sender, EventArgs e)
        {
            UrediRezervaciju urediRezervaciju = new UrediRezervaciju();
            urediRezervaciju.Show();
        }
    }
}

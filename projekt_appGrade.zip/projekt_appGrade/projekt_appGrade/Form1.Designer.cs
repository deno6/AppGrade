﻿namespace projekt_appGrade
{
    partial class glavnaForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.članoviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dodajNovogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pregledajPostojećeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obrišiČlanaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pregledToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rezervacijeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pregledajToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.računToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.izdajNoviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pregledajToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.članoviToolStripMenuItem,
            this.sportToolStripMenuItem,
            this.rezervacijeToolStripMenuItem,
            this.računToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(767, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // članoviToolStripMenuItem
            // 
            this.članoviToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dodajNovogToolStripMenuItem,
            this.pregledajPostojećeToolStripMenuItem,
            this.obrišiČlanaToolStripMenuItem});
            this.članoviToolStripMenuItem.Name = "članoviToolStripMenuItem";
            this.članoviToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.članoviToolStripMenuItem.Text = "Članovi";
            // 
            // sportToolStripMenuItem
            // 
            this.sportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pregledToolStripMenuItem});
            this.sportToolStripMenuItem.Name = "sportToolStripMenuItem";
            this.sportToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.sportToolStripMenuItem.Text = "Sport";
            // 
            // dodajNovogToolStripMenuItem
            // 
            this.dodajNovogToolStripMenuItem.Name = "dodajNovogToolStripMenuItem";
            this.dodajNovogToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.dodajNovogToolStripMenuItem.Text = "Dodaj novog...";
            // 
            // pregledajPostojećeToolStripMenuItem
            // 
            this.pregledajPostojećeToolStripMenuItem.Name = "pregledajPostojećeToolStripMenuItem";
            this.pregledajPostojećeToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.pregledajPostojećeToolStripMenuItem.Text = "Pregledaj postojeće...";
            // 
            // obrišiČlanaToolStripMenuItem
            // 
            this.obrišiČlanaToolStripMenuItem.Name = "obrišiČlanaToolStripMenuItem";
            this.obrišiČlanaToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.obrišiČlanaToolStripMenuItem.Text = "Obriši člana...";
            // 
            // pregledToolStripMenuItem
            // 
            this.pregledToolStripMenuItem.Name = "pregledToolStripMenuItem";
            this.pregledToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pregledToolStripMenuItem.Text = "Pregled...";
            // 
            // rezervacijeToolStripMenuItem
            // 
            this.rezervacijeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pregledajToolStripMenuItem});
            this.rezervacijeToolStripMenuItem.Name = "rezervacijeToolStripMenuItem";
            this.rezervacijeToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.rezervacijeToolStripMenuItem.Text = "Rezervacije";
            // 
            // pregledajToolStripMenuItem
            // 
            this.pregledajToolStripMenuItem.Name = "pregledajToolStripMenuItem";
            this.pregledajToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pregledajToolStripMenuItem.Text = "Pregledaj...";
            // 
            // računToolStripMenuItem
            // 
            this.računToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.izdajNoviToolStripMenuItem,
            this.pregledajToolStripMenuItem1});
            this.računToolStripMenuItem.Name = "računToolStripMenuItem";
            this.računToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.računToolStripMenuItem.Text = "Račun";
            // 
            // izdajNoviToolStripMenuItem
            // 
            this.izdajNoviToolStripMenuItem.Name = "izdajNoviToolStripMenuItem";
            this.izdajNoviToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.izdajNoviToolStripMenuItem.Text = "Izdaj novi...";
            // 
            // pregledajToolStripMenuItem1
            // 
            this.pregledajToolStripMenuItem1.Name = "pregledajToolStripMenuItem1";
            this.pregledajToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.pregledajToolStripMenuItem1.Text = "Pregledaj...";
            // 
            // glavnaForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 420);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "glavnaForma";
            this.Text = "AppGrade";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem članoviToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dodajNovogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pregledajPostojećeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obrišiČlanaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pregledToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rezervacijeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pregledajToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem računToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem izdajNoviToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pregledajToolStripMenuItem1;

    }
}

